#!/usr/bin/env python2
#
#  Epour - A bittorrent client using EFL and libtorrent
#
#  Copyright 2012-2013 Kai Huuhko <kai.huuhko@gmail.com>
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#

import sys
import os

import dbus, e_dbus
ml = e_dbus.DBusEcoreMainLoop()
dbus.set_default_main_loop(ml)
import dbus.service
bus = dbus.SessionBus()

dbo = None
try:
    dbo = bus.get_object("net.launchpad.epour", "/net/launchpad/epour")
except dbus.exceptions.DBusException:
    pass

if dbo:
    if sys.argv[1:]:
        for f in sys.argv[1:]:
            dbo.AddTorrent(f, dbus_interface="net.launchpad.epour")
    sys.exit()

import mimetypes
import ConfigParser
import cPickle
import urllib
import HTMLParser

import libtorrent as lt

import elementary as elm
from ecore import timer_add

from Globals import conf_dir, conf_path, data_dir
from gui import MainInterface

class Epour(object):
    def __init__(self, torrents=None):
        # Setup and try to restore session
        session = self.session = Session(self)
        session.load_state()

        # Setup GUI
        self.gui = MainInterface(self)

        # Restore torrents
        session.load_torrents()

        # Add torrents from command line
        if torrents:
            for t in torrents:
                self.add_torrent(t)

        self.dbusname = dbus.service.BusName("net.launchpad.epour", dbus.SessionBus())
        self.dbo = EpourDBus(self)

        # Update timer
        timer = timer_add(1.0, self.update)

    def update(self):
        while 1:
            a = self.session.pop_alert()
            if not a: break
            try:
                h = a.handle
            except:
                pass
            else:
                if h.is_valid():
                    try:
                        i = h.get_torrent_info()
                    except:
                        pass
                ihash = str(h.info_hash())
            if isinstance(a, lt.state_changed_alert) \
            or isinstance(a, lt.torrent_paused_alert) \
            or isinstance(a, lt.torrent_resumed_alert):
                self.gui.update_icon(ihash)
            elif isinstance(a, lt.metadata_received_alert):
                md = lt.bdecode(i.metadata())
                t = {}
                t["info"] = md
                t_path = os.path.join(data_dir, i.name()+".torrent")
                with open(t_path, "wb") as f:
                    f.write(lt.bencode(t))
                self.session.torrents[ihash] = t_path
            else:
                print(a)

        self.gui.update_text(self.session)

        return 1

    def quit(self):
        session = self.session

        session.pause()
        session.save_torrents()
        session.save_state()

        elm.exit()

class Session(lt.session):
    def __init__(self, parent):
        self.parent = parent
        lt.session.__init__(self)

        self.handles = {}
        self.torrents = {}

                #sdpipsdtsppe
                #theprtertoer
                #atrboabaorer
                #t|flgtucrtro
                #s|oorugkam|r
                #||rces|ega||
                #||mks||rep||
        mask = 0b000001000001
        self.set_alert_mask(mask)

        self.conf = self.setup_conf()

        # TODO: get these from conf
        self.listen_on(6881, 6891)

    def setup_conf(self):
        conf = ConfigParser.SafeConfigParser()

        for d in conf_dir, data_dir:
            if not os.path.exists(d):
                os.mkdir(d, 0700)
        if not os.path.exists(os.path.join(conf_path)):
            conf.add_section("Settings")
            conf.set("Settings", "storage_path", os.path.expanduser(os.path.join("~", "Downloads")))
            with open(conf_path, 'wb') as configfile:
                conf.write(configfile)
        conf.read(conf_path)

        return conf

    def save_conf(self):
        with open(conf_path, 'wb') as configfile:
            self.conf.write(configfile)

    def load_state(self):
        try:
            with open(os.path.join(data_dir, "session"), 'rb') as f:
                state = lt.bdecode(f.read())
            lt.session.load_state(self, state)
        except:
            pass

    def save_state(self):
        state = lt.session.save_state(self)

        with open(os.path.join(data_dir, "session"), 'wb') as f:
            f.write(lt.bencode(state))

    def load_torrents(self):
        # Restore torrents
        try:
            pkl_file = open(os.path.join(data_dir, "torrents"), 'rb')
        except IOError:
            pass
        else:
            try:
                paths = cPickle.load(pkl_file)
            except EOFError:
                pass
            else:
                for k, v in paths.iteritems():
                    print("Restoring torrent %s" % v)
                    self.add_torrent(v)
            pkl_file.close()

    def save_torrents(self):
        with open(os.path.join(data_dir, "torrents"), 'wb') as f:
            cPickle.dump(self.torrents, f)

        for h in self.handles.itervalues():
            if not h.is_valid() or not h.has_metadata():
                continue
            data = lt.bencode(h.write_resume_data())
            with open(os.path.join(data_dir, h.get_torrent_info().name() + '.fastresume'), 'wb') as f:
                f.write(data)

    def add_torrent(self, t):
        if not t:
            return

        storage_path = self.conf.get("Settings", "storage_path")

        if not t.startswith("magnet"):
            mimetype = mimetypes.guess_type(t)[0]
            if not mimetype == "application/x-bittorrent":
                print("Invalid file")
                return

            e = lt.bdecode(open(t, 'rb').read())
            info = lt.torrent_info(e)
            rd = None
            try:
                with open(os.path.join(data_dir, info.name() + ".fastresume"), "rb") as f:
                    rd = lt.bdecode(f.read())
            except:
                print("Invalid resume data")
            h = lt.session.add_torrent(self, info, storage_path, resume_data=rd)
        else:
            t = urllib.unquote(t)
            t = str(HTMLParser.HTMLParser().unescape(t))
            h = lt.add_magnet_uri(self, t, { "save_path": str(storage_path) })

        if not h.is_valid():
            print("Invalid torrent handle")
            return

        ihash = str(h.info_hash())

        self.torrents[ihash] = t
        self.handles[ihash] = h

        self.parent.gui.add_torrent_item(h)

    def remove_torrent(self, h, with_data=False):
        ihash = str(h.info_hash())
        del self.torrents[ihash]
        self.session.remove_torrent(h, option=with_data)

        # TODO: Cleanup fast resume/torrent file

        return ihash

class EpourDBus(dbus.service.Object):
    def __init__(self, parent):
        self.parent = parent
        dbus.service.Object.__init__(self, dbus.SessionBus(), "/net/launchpad/epour", "net.launchpad.epour")

        self.props = {
        }

    @dbus.service.method(dbus_interface='net.launchpad.epour',
                         in_signature='s', out_signature='')
    def AddTorrent(self, f):
        self.parent.add_torrent(None, str(f))

if __name__ == "__main__":
    elm.init()
    epour = Epour(sys.argv[1:])
    elm.run()
    elm.shutdown()
