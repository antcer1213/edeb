import os

conf_dir = os.path.expanduser(os.path.join("~", ".config", "epour"))
conf_path = os.path.join(conf_dir, "epour.conf")
data_dir = os.path.expanduser(os.path.join("~", ".local", "share", "epour"))
