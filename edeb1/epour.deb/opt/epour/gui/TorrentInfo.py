#
#  Epour - A bittorrent client using EFL and libtorrent
#
#  Copyright 2012-2013 Kai Huuhko <kai.huuhko@gmail.com>
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#

import elementary as elm

class FileSelectionClass(elm.GenlistItemClass):
    def text_get(self, obj, part, info):
        return info

    def content_get(self, obj, part, h):
        if part == "elm.swallow.icon":
            check = Check(obj)
            check.callback_changed_add(self.toggle_torrent_enabled, h)
            return check
        elif part == "elm.swallow.end":
            pri = Hoversel(obj)
            pri.callback_selected_add(self.priority_selected, h)
            return pri

class TorrentInfo(elm.InnerWindow):
    def __init__(self, parent, h):
        self.parentwin = parent.win
        elm.InnerWindow.__init__(self, parent.win)

        files = elm.Genlist(self)
        files.size_hint_align_set(-1.0, -1.0)
        files.size_hint_weight_set(1.0, 1.0)
        files.show()

        xbtn = elm.Button(self)
        xbtn.text_set("Close")
        xbtn.callback_clicked_add(lambda x: self.delete())
        xbtn.show()

        box = elm.Box(self)
        box.size_hint_align_set(-1.0, -1.0)
        box.pack_end(files)
        box.pack_end(xbtn)
        box.show()

        self.content_set(box)
        self.activate()
