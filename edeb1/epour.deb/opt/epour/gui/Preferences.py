#
#  Epour - A bittorrent client using EFL and libtorrent
#
#  Copyright 2012-2013 Kai Huuhko <kai.huuhko@gmail.com>
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#

import os

import elementary as elm

import Notify

class Preferences(elm.InnerWindow):
    def __init__(self, parent, session):
        self.session = session
        elm.InnerWindow.__init__(self, parent.win)

        self.limit_widgets = {}
        self.num_widgets = {}

        limit_units = ( "kB/s", "MB/s", "GB/s" )

        self.limits = (
            ( "Upload limit", session.upload_rate_limit, session.set_upload_rate_limit, ),
            ( "Download limit", session.download_rate_limit, session.set_download_rate_limit ),
            ( "Local upload limit", session.local_upload_rate_limit, session.set_local_upload_rate_limit ),
            ( "Local download limit", session.local_download_rate_limit, session.set_local_download_rate_limit ),
        )

        mbox = elm.Box(self)
        mbox.size_hint_weight_set(1, 1)
        mbox.size_hint_align_set(-1, -1)

        for text, rfunc, wfunc in self.limits:
            f = elm.Frame(self)
            f.size_hint_align = (-1, 0)
            f.text = text

            b = elm.Box(self)
            b.horizontal = True
            b.show()

            s = elm.Spinner(self)
            s.min_max = 0, 1024
            s.show()
            b.pack_end(s)

            hs = elm.Hoversel(self)
            hs.text = limit_units[0]
            for u in limit_units:
                hs.item_add(u, None, 0, lambda x=hs, y=None, u=u: x.text_set(u))
            hs.show()
            b.pack_end(hs)

            l = rfunc()
            if l > 1024*1024*1024:
                hs.text = "GB/s"
                s.value = round(l/(1024*1024*1024))
            elif l > 1024*1024:
                hs.text = "MB/s"
                s.value = round(l/(1024*1024))
            elif l > 1024:
                s.value = round(l/(1024))

            self.limit_widgets[text] = (s, hs)

            f.content = b
            f.show()
            mbox.pack_end(f)

        # Listen port
        f = elm.Frame(self)
        f.text = "Listen port (range)"

        b = elm.Box(self)
        b.horizontal = True

        l = self.listenlow = elm.Spinner(self)
        l.min_max = 0, 65535
        l.show()
        l.value = session.listen_port()
        b.pack_end(l)

        h = self.listenhigh = elm.Spinner(self)
        h.min_max = 0, 65535
        h.show()
        h.value = session.listen_port()
        b.pack_end(h)

        f.content = b
        #f.show()
        #mbox.pack_end(f)

        lbl = elm.Label(self)
        lbl.text_set("Torrent data storage path")
        self.dlsel = dlsel = elm.FileselectorEntry(self)
        dlsel.size_hint_align = (-1.0, 0.0)
        dlsel.inwin_mode = True
        dlsel.folder_only = True
        dlsel.text = "Select data storage path"
        dlsel.path_set(self.session.conf.get("Settings", "storage_path"))
        dlsel.show()
        lbl.show()
        mbox.pack_end(dlsel)

        btnb = elm.Box(self)
        btnb.horizontal = True

        save = elm.Button(self)
        save.text_set("Save")
        save.callback_clicked_add(self.save_cb)
        save.show()
        btnb.pack_end(save)

        xbtn = elm.Button(self)
        xbtn.text_set("Close")
        xbtn.callback_clicked_add(lambda x: self.delete())
        xbtn.show()
        btnb.pack_end(xbtn)

        btnb.show()
        mbox.pack_end(btnb)

        scr = elm.Scroller(self)
        scr.policy = elm.ELM_SCROLLER_POLICY_OFF, elm.ELM_SCROLLER_POLICY_AUTO
        scr.content = mbox

        self.content = scr
        self.activate()

    def save_cb(self, btn):
        for text, rfunc, wfunc in self.limits:
            s, hs = self.limit_widgets[text]
            v, u = s.value, hs.text
            if u == "kB/s":
                v = int(v*1024)
            elif u == "MB/s":
                v = int(v*1024*1024)
            elif u == "GB/s":
                v = int(v*1024*1024*1024)
            wfunc(v)

        if not os.path.exists(self.dlsel.path):
            p = Notify.Error(self, "Invalid storage path", "You have selected an invalid data storage path for torrents.")
            return
        self.session.conf.set("Settings", "storage_path", self.dlsel.path)
        self.session.save_conf()

        #self.session.listen_on(int(self.listenlow.value), int(self.listenhigh.value))
        self.delete()


# TODO:
# max uploads?
# max conns?
# max half open conns?

# ip filter

# encryption:
# enc in policy
# enc out policy
# allowed enc level
# prefer enc

# proxy settings:
# hostname
# port
# username
# password
# proxytype

