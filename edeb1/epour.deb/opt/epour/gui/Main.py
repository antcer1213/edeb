#
#  Epour - A bittorrent client using EFL and libtorrent
#
#  Copyright 2012-2013 Kai Huuhko <kai.huuhko@gmail.com>
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#

import os

from evas import EVAS_ASPECT_CONTROL_VERTICAL
import elementary as elm

from TorrentInfo import TorrentInfo
from Preferences import Preferences

class TorrentClass(elm.GenlistItemClass):
    def text_get(self, obj, part, item_data):
        state_str = ['Queued', 'Checking', 'Downloading metadata', \
            'Downloading', 'Finished', 'Seeding', 'Allocating', \
            'Checking resume data']

        h = item_data
        if h.has_metadata():
            name = h.get_torrent_info().name()
        else:
            name = '-'

        if part == "elm.text":
            return '%s' % (
                name
            )
        elif part == "elm.text.sub":
            s = h.status()
            return '%s - %.2f%% complete (down: %.1f kb/s up: %.1f kB/s peers: %d)' % (
                state_str[s.state],
                s.progress * 100,
                s.download_payload_rate / 1000,
                s.upload_payload_rate / 1000,
                s.num_peers
            )

    def content_get(self, obj, part, item_data):
        h = item_data
        if part == "elm.swallow.icon":
            s = h.status()
            ic = elm.Icon(obj)
            if h.is_paused():
                ic.standard = "player_pause"
            elif h.is_seed():
                ic.standard = "player_play"
            else:
                ic.standard = "player_record"
            ic.size_hint_aspect_set(EVAS_ASPECT_CONTROL_VERTICAL, 1, 1)
            return ic
        elif part == "elm.swallow.end":
            btn = elm.Button(obj)
            btn.text_set("Pause/Resume")
            btn.callback_clicked_add(self.toggle_torrent_paused, h)
            return btn

    def toggle_torrent_paused(self, btn, h):
        s = h.status()
        if s.paused:
            h.resume()
            h.auto_managed(True)
        else:
            h.auto_managed(False)
            h.pause()

class MainInterface(object):
    def __init__(self, parent):
        self.parent = parent
        self.win = elm.StandardWindow("epour", "Epour")
        self.win.callback_delete_request_add(self.quit)

        self.torrentitems = {}

        # GUI
        box = elm.Box(self.win)
        box.size_hint_weight_set(1.0, 1.0)
        self.win.resize_object_add(box)
        box.show()

        self.tlist = tlist = elm.Genlist(self.win)
        tlist.callback_clicked_double_add(self.list_double_click_cb)
        tlist.homogeneous_set(True)
        tlist.size_hint_weight_set(1.0, 1.0)
        tlist.size_hint_align_set(-1.0, -1.0)
        box.pack_end(tlist)
        tlist.show()

        s = parent.session.status()
        status = self.status = elm.Label(self.win)
        status.text_set("down: %.1f kb/s up: %.1f kB/s peers: %d" % \
            (s.payload_download_rate, s.payload_upload_rate, s.num_peers))
        box.pack_end(status)
        status.show()

        btnbox = elm.Box(self.win)
        btnbox.horizontal = True
        btnbox.size_hint_align_set(-1.0, 0.0)

        addbtn = elm.Button(self.win)
        addbtn.text_set("Add torrent")
        addbtn.callback_clicked_add(self.select_torrent)
        btnbox.pack_end(addbtn)
        addbtn.show()

        togglebtn = self.togglebtn = elm.Button(self.win)
        togglebtn.text_set("Resume all" if parent.session.is_paused() else "Pause all")
        togglebtn.callback_clicked_add(self.toggle_paused_cb)
        btnbox.pack_end(togglebtn)
        togglebtn.show()

        prefbtn = elm.Button(self.win)
        prefbtn.text = "Preferences"
        prefbtn.callback_clicked_add(self.prefs_cb)
        prefbtn.show()
        btnbox.pack_end(prefbtn)

        box.pack_end(btnbox)
        btnbox.show()

        self.win.resize(480, 480)
        self.win.show()

    def update_text(self, session):
        for v in self.torrentitems.itervalues():
            v.fields_update("elm.text", elm.ELM_GENLIST_ITEM_FIELD_TEXT)
            v.fields_update("elm.text.sub", elm.ELM_GENLIST_ITEM_FIELD_TEXT)
        s = session.status()
        self.status.text_set("down: %.1f kB/s up: %.1f kB/s peers: %d" % (
            s.payload_download_rate / 1000,
            s.payload_upload_rate / 1000,
            s.num_peers
        ))

    def update_icon(self, ihash):
        self.torrentitems[ihash].fields_update("elm.swallow.icon", elm.ELM_GENLIST_ITEM_FIELD_CONTENT)

    def select_torrent(self, btn):
        sel = elm.Fileselector(self.win)
        sel.path_set(os.path.expanduser("~"))
        sel.size_hint_weight_set(1.0, 1.0)
        sel.size_hint_align_set(-1.0, -1.0)
        sel.show()
        sf = elm.Frame(self.win)
        sf.size_hint_weight_set(1.0, 1.0)
        sf.size_hint_align_set(-1.0, -1.0)
        sf.text = "Select torrent file"
        sf.content = sel
        sf.show()

        magnet = elm.Entry(self.win)
        magnet.single_line = True
        magnet.scrollable = True
        magnet.show()
        mf = elm.Frame(self.win)
        mf.size_hint_weight_set(1.0, 0.0)
        mf.size_hint_align_set(-1.0, 0.0)
        mf.text = "Or enter magnet URI here"
        mf.content = magnet
        mf.show()
        mbtn = elm.Button(self.win)
        mbtn.text = "Done"
        mbtn.show()
        mbox = elm.Box(self.win)
        mbox.size_hint_weight_set(1.0, 0.0)
        mbox.size_hint_align_set(-1.0, 0.0)
        mbox.horizontal = True
        mbox.pack_end(mf)
        mbox.pack_end(mbtn)
        mbox.show()

        box = elm.Box(self.win)
        box.size_hint_weight = (1.0, 1.0)
        box.size_hint_align = (-1.0, -1.0)
        box.pack_end(sf)
        box.pack_end(mbox)
        box.show()

        self.inwin = inwin = elm.InnerWindow(self.win)
        inwin.content = box
        sel.callback_done_add(self.add_torrent_cb)
        sel.callback_done_add(lambda x, y: inwin.delete())
        mbtn.callback_clicked_add(self.add_magnet_uri_cb, magnet)
        mbtn.callback_clicked_add(lambda x: inwin.delete())
        inwin.activate()

    def add_magnet_uri_cb(self, btn, magnet):
        m = magnet.text
        if m:
            self.add_torrent_cb(None, m)

    def add_torrent_cb(self, filesel, t):
        if not t:
            return

        self.parent.session.add_torrent(t)

    def add_torrent_item(self, h):
        ihash = str(h.info_hash())

        itc = TorrentClass("double_label")
        item = self.tlist.item_append(itc, h)
        self.torrentitems[ihash] = item

    def toggle_paused_cb(self, btn):
        session = self.parent.session
        if session.is_paused():
            session.resume()
            btn.text = "Pause all"
        else:
            session.pause()
            btn.text = "Resume all"

    def prefs_cb(self, btn):
        self.prefs = Preferences(self, self.parent.session)

    def list_double_click_cb(self, gl, item):
        h = item.data
        cp = elm.Ctxpopup(self.win)
        cp.item_append("Remove torrent", None, self.remove_torrent_cb, item, h, False)
        cp.item_append("Remove torrent and files", None, self.remove_torrent_cb, item, h, True)
        #cp.item_append("Torrent preferences", None, self.torrent_preferences_cb, h)
        cp.pos = self.win.evas.pointer_canvas_xy_get()
        cp.show()

    def remove_torrent_cb(self, cp, item, glitem, h, with_data=False):
        item.widget_get().dismiss()
        ihash = self.parent.session.remove_torrent(h, with_data)
        glitem.delete()
        del self.torrentitems[ihash]
        del glitem

    def torrent_preferences_cb(self, cp, item, h):
        item.widget_get().dismiss()
        self.i = TorrentInfo(self, h)

    def quit(self, *args):
        self.parent.quit()
